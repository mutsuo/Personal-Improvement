#ifndef DEF_ELS_HEAD
#define DEF_ELS_HEAD

#include <windows.h>
#include"resource.h"


void tePaint(HDC hDC);
void PaintSqare(HDC hmemDC);


#endif
